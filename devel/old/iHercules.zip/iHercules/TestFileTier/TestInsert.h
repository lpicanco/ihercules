void TestInsert(char *pszFileName);
