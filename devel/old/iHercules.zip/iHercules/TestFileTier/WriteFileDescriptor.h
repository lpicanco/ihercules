#if !defined(WriteFileDescriptor_h)
#define WriteFileDescriptor_h
    
    void WriteFileDescriptor(const char *pszFileName);

#endif