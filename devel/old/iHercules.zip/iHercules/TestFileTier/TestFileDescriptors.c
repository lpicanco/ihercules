/************************************************************************/
/* TestFileDescriptors.c: Testa a estrutura interna de um arquivo.      */
/************************************************************************/

#include "TestInsert.h"
#include <string.h>

void main()
{
    TestInsert("c:\\temp\\data.ihs");
}